// components/Header.js
import { Link } from "react-router-dom";
import "../App.css";

export default function Header() {
  return (
    <header className="header">
      <div className="logo-section">
      <img src="/logo.png" alt="Logo" className="logo" />

      <span className="company-name">Brown Ivory<br />Group</span>

      </div>
      <nav className="nav-links">
        <Link to="/">Home</Link>
        <a href="#">About</a>
        <a href="#">Services</a>
        <a href="#">Contact</a>
      </nav>
      <div className="auth-buttons">
      <Link to="/login" className="login-link">Login</Link>

        <Link to="/choose-user-type" className="get-started-button">Get Started</Link>
      </div>
    </header>
  );
}
