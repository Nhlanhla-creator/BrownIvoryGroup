import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../App.css";

export default function ChooseUserType() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState(null);

  const handleContinue = () => {
    if (selected === "sme") {
      navigate("/register-sme");
    } else if (selected === "investor") {
      navigate("/register-investor");
    }
  };

  return (
    <div className="choose-user-container">
      <h2>Let's Get You Started</h2>
      <p>Are you joining us as a business or an investor?</p>
      <div className="user-type-cards">
        <div
          className={`user-card ${selected === "sme" ? "selected" : ""}`}
          onClick={() => setSelected("sme")}
        >
          <input
            type="radio"
            id="sme"
            name="userType"
            checked={selected === "sme"}
            onChange={() => setSelected("sme")}
          />
          <label htmlFor="sme">
            <img src="/business-icon.png" alt="SME" />
            <h3>SME / Business</h3>
            <p>Access tools, markets, and expert advice for business growth.</p>
          </label>
        </div>
        <div
          className={`user-card ${selected === "investor" ? "selected" : ""}`}
          onClick={() => setSelected("investor")}
        >
          <input
            type="radio"
            id="investor"
            name="userType"
            checked={selected === "investor"}
            onChange={() => setSelected("investor")}
          />
          <label htmlFor="investor">
            <img src="/investor-icon.png" alt="Investor" />
            <h3>Funder / Investor</h3>
            <p>Find promising opportunities and empower African entrepreneurs.</p>
          </label>
        </div>
      </div>

      <button
        className="continue-button"
        disabled={!selected}
        onClick={handleContinue}
      >
        Continue
      </button>
    </div>
  );
}
