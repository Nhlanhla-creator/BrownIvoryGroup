import React, { useState } from "react";
import Select from "react-select";
import "../App.css";

const businessStageOptions = [
    { value: "Idea stage", label: "Idea stage" },
    { value: "Prototype ready", label: "Prototype ready" },
    { value: "Early traction", label: "Early traction" },
    { value: "Revenue-generating", label: "Revenue-generating" },
    { value: "Scaling/growth", label: "Scaling/growth" }
];

const industryOptions = [
    "Agriculture", "Technology", "Health", "Finance", "Education",
    "Manufacturing", "Retail", "Logistics", "Tourism", "Energy", "Real Estate"
].map(ind => ({ value: ind, label: ind }));

const africanCountries = [
    "Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cabo Verde",
    "Cameroon", "Central African Republic", "Chad", "Comoros", "Congo (Brazzaville)",
    "Congo (Kinshasa)", "Djibouti", "Egypt", "Equatorial Guinea", "Eritrea", "Eswatini",
    "Ethiopia", "Gabon", "Gambia", "Ghana", "Guinea", "Guinea-Bissau", "Ivory Coast",
    "Kenya", "Lesotho", "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania",
    "Mauritius", "Morocco", "Mozambique", "Namibia", "Niger", "Nigeria", "Rwanda",
    "São Tomé and Príncipe", "Senegal", "Seychelles", "Sierra Leone", "Somalia",
    "South Africa", "South Sudan", "Sudan", "Tanzania", "Togo", "Tunisia", "Uganda",
    "Zambia", "Zimbabwe"
];

const locationOptions = ["Yes", "No", "Doesn’t matter"];

const steps = [
    { id: 1, title: "Personal Details" },
    { id: 2, title: "Business Info" },
    { id: 3, title: "Security" }
];

export default function RegisterForm() {
    const [step, setStep] = useState(1);
    const [form, setForm] = useState({
        fullName: "", email: "", contact: "", country: "",
        industries: [], stages: [], investmentAmount: "", locationPreference: "",
        password: "", confirmPassword: "", code: "", terms: false
    });
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setForm({ ...form, [name]: type === "checkbox" ? checked : value });
    };

    const handleSelectChange = (selected, fieldName) => {
        setForm({ ...form, [fieldName]: selected.map(item => item.value) });
    };

    const validate = () => {
        const newErrors = {};
        if (!form.fullName) newErrors.fullName = "Full name is required";

        if (!form.email) {
            newErrors.email = "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(form.email)) {
            newErrors.email = "Email format is invalid";
        }

        if (!form.contact) {
            newErrors.contact = "Contact is required";
        } else if (!/^\d{7,15}$/.test(form.contact)) {
            newErrors.contact = "Enter a valid phone number (7-15 digits)";
        }

        if (step === 2) {
            if (!form.stages.length) newErrors.stages = "Select at least one business stage";
            if (!form.industries.length) newErrors.industries = "Select at least one industry";

            if (!form.investmentAmount) {
                newErrors.investmentAmount = "Investment amount is required";
            } else if (!/^\d+$/.test(form.investmentAmount)) {
                newErrors.investmentAmount = "Only numeric values allowed";
            }

            if (!form.locationPreference) newErrors.locationPreference = "Please select a preference";
            if (!form.country) newErrors.country = "Country is required";
        }

        if (step === 3) {
            if (!form.password) {
                newErrors.password = "Password is required";
            } else if (form.password.length < 6) {
                newErrors.password = "Password must be at least 6 characters";
            }
            if (form.password !== form.confirmPassword) {
                newErrors.confirmPassword = "Passwords do not match";
            }
            if (!form.terms) newErrors.terms = "You must agree to terms";
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const next = () => {
        if (validate()) setStep(step + 1);
    };

    const back = () => setStep(step - 1);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (validate()) setIsSubmitted(true);
    };

    if (isSubmitted) {
        return (
            <div className="form-wrapper">
                <h3>Email Verification</h3>
                <p>We’ve sent a verification code to <strong>{form.email}</strong>. Please check your inbox.</p>
                <form onSubmit={(e) => {
                    e.preventDefault();
                    alert("Email Verified!");
                }}>
                    <label>Verification Code:</label>
                    <input
                        name="code"
                        value={form.code}
                        onChange={handleChange}
                        placeholder="Enter code..."
                    />
                    <button type="submit">Verify</button>
                </form>
                <p style={{ marginTop: "1rem" }}>
                    Didn’t get it? <button type="button" onClick={() => alert("Resend code logic here")}>Resend Code</button>
                </p>
            </div>
        );
    }

    return (
        <div className="form-wrapper">
            <h2>Register</h2>

            <div className="step-tracker">
                {steps.map((s, idx) => (
                    <div key={s.id} className={`step ${step === s.id ? "active" : step > s.id ? "completed" : ""}`}>
                        <div className="circle">{s.id}</div>
                        <div className="label">{s.title}</div>
                        {idx < steps.length - 1 && <div className="line" />}
                    </div>
                ))}
            </div>

            <form onSubmit={handleSubmit}>
                {step === 1 && (
                    <div className="form-section">
                        <h3>Personal Details</h3>
                        <label>Full Name:</label>
                        <input name="fullName" value={form.fullName} onChange={handleChange} placeholder="Full Name..." />
                        {errors.fullName && <div className="error">{errors.fullName}</div>}

                        <label>Email:</label>
                        <input type="email" name="email" value={form.email} onChange={handleChange} placeholder="Email..." />
                        {errors.email && <div className="error">{errors.email}</div>}

                        <label>Contact:</label>
                        <input
                            type="tel"
                            name="contact"
                            value={form.contact}
                            onChange={(e) => {
                                const val = e.target.value;
                                if (/^\d*$/.test(val)) handleChange(e);
                            }}
                            placeholder="Contact..."
                        />
                        {errors.contact && <div className="error">{errors.contact}</div>}
                    </div>
                )}

                {step === 2 && (
                    <div className="form-section">
                        <h3>Business Info</h3>

                        <label>Business Stages:</label>
                        <Select
                            isMulti
                            name="stages"
                            options={businessStageOptions}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            onChange={(selected) => handleSelectChange(selected, "stages")}
                            value={businessStageOptions.filter(option => form.stages.includes(option.value))}
                            placeholder="Select business stage(s)..."
                        />
                        {errors.stages && <div className="error">{errors.stages}</div>}

                        <label>Industries of Interest:</label>
                        <Select
                            isMulti
                            name="industries"
                            options={industryOptions}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            onChange={(selected) => handleSelectChange(selected, "industries")}
                            value={industryOptions.filter(option => form.industries.includes(option.value))}
                            placeholder="Select industries..."
                        />
                        {errors.industries && <div className="error">{errors.industries}</div>}

                        <label>Typical Investment Amount:</label>
                        <input
                            type="text"
                            name="investmentAmount"
                            value={form.investmentAmount}
                            onChange={(e) => {
                                const val = e.target.value;
                                if (/^\d*$/.test(val)) handleChange(e);
                            }}
                            placeholder="e.g. R20,000"
                        />
                        {errors.investmentAmount && <div className="error">{errors.investmentAmount}</div>}

                        <label>Do you prefer local businesses?</label>
                        <select name="locationPreference" value={form.locationPreference} onChange={handleChange}>
                            <option value="">Choose an option...</option>
                            {locationOptions.map((opt, i) => (
                                <option key={i} value={opt}>{opt}</option>
                            ))}
                        </select>
                        {errors.locationPreference && <div className="error">{errors.locationPreference}</div>}

                        <label>Country:</label>
                        <select name="country" value={form.country} onChange={handleChange}>
                            <option value="">Choose an option...</option>
                            {africanCountries.map((c, i) => (
                                <option key={i} value={c}>{c}</option>
                            ))}
                        </select>
                        {errors.country && <div className="error">{errors.country}</div>}
                    </div>
                )}

                {step === 3 && (
                    <div className="form-section">
                        <h3>Security</h3>
                        <label>Password:</label>
                        <input type="password" name="password" value={form.password} onChange={handleChange} placeholder="Password..." />
                        {errors.password && <div className="error">{errors.password}</div>}

                        <label>Confirm Password:</label>
                        <input type="password" name="confirmPassword" value={form.confirmPassword} onChange={handleChange} placeholder="Confirm Password..." />
                        {errors.confirmPassword && <div className="error">{errors.confirmPassword}</div>}

                        <label className="checkbox">
                            <input type="checkbox" name="terms" checked={form.terms} onChange={handleChange} />
                            I agree to the terms and conditions
                        </label>
                        {errors.terms && <div className="error">{errors.terms}</div>}
                    </div>
                )}

                <div className="form-buttons">
                    {step > 1 && <button type="button" onClick={back}>Back</button>}
                    {step < 3 ? (
                        <button type="button" onClick={next}>Continue</button>
                    ) : (
                        <button type="submit">Register</button>
                    )}
                </div>
            </form>
        </div>
    );
}
