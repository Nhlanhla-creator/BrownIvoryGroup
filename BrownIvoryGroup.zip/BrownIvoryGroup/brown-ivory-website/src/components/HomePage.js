import { Link } from "react-router-dom";
import "../App.css";

export default function HomePage() {
  return (
    <div className="homepage-container">
      <section className="hero-section">
        <div className="overlay"></div>
        <div className="hero-content fade-in">
          <h1>
            Welcome To Brown Ivory Group (BIG)<br />
            <span className="highlight">BIG</span> on Ideas, <span className="highlight">BIG</span> on Growth,<br />
            <span className="highlight">BIG</span> on Impact
          </h1>
          <p>
            Delivering integrated solutions through expert consulting,
            market access, investor connections, and impactful
            community engagement.
          </p>
          <div className="hero-buttons">
            <Link to="/choose-user-type" className="btn-light">Get Started</Link>
            <a href="#" className="btn-dark">Our Services</a>
          </div>
        </div>
       
      
      </section>
    </div>
  );
}
