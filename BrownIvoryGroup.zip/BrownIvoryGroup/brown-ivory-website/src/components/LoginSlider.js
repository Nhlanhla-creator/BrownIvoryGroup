import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../App.css";

export default function LoginSlider() {
  const [activeTab, setActiveTab] = useState("sme");
  const [form, setForm] = useState({ email: "", password: "" });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleLogin = (e) => {
    e.preventDefault();
    console.log(`${activeTab.toUpperCase()} login`, form);
    // Handle login logic here
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-left">
          <h2>{activeTab === "sme" ? "SME Login" : "Investor Login"}</h2>
          <form className="login-form" onSubmit={handleLogin}>
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={form.email}
              onChange={handleChange}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={form.password}
              onChange={handleChange}
              required
            />
            <button type="submit">Login</button>
            <div className="text-link">
              <Link to="#">Forgot password?</Link>
            </div>
            <div className="text-link">
              {activeTab === "sme" ? (
                <>
                  Don't have an account?{" "}
                  <Link to="/register-sme">Register as SME</Link>
                </>
              ) : (
                <>
                  Don't have an account?{" "}
                  <Link to="/register-investor">Register as Investor</Link>
                </>
              )}
            </div>
          </form>
        </div>

        <div className="login-right">
          <h3>Switch Login</h3>
          <p>
            {activeTab === "sme"
              ? "Are you an investor or funder?"
              : "Are you a business or SME?"}
          </p>
          <button onClick={() => setActiveTab(activeTab === "sme" ? "investor" : "sme")}>
            {activeTab === "sme" ? "Login as Investor" : "Login as SME"}
          </button>
        </div>
      </div>
    </div>
  );
}
