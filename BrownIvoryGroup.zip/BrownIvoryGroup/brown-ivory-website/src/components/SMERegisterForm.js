import React, { useState } from "react";
import "../App.css"; // We'll add styles for the tracker here

const businessStages = [
    "Idea stage", "Prototype ready", "Early traction",
    "Revenue-generating", "Scaling/growth"
];

const industries = [
    "Agriculture", "Technology", "Health", "Finance", "Education",
    "Manufacturing", "Retail", "Logistics", "Tourism", "Energy", "Real Estate"
];

const africanCountries = [
    "Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cabo Verde",
    "Cameroon", "Central African Republic", "Chad", "Comoros", "Congo (Brazzaville)",
    "Congo (Kinshasa)", "Djibouti", "Egypt", "Equatorial Guinea", "Eritrea", "Eswatini",
    "Ethiopia", "Gabon", "Gambia", "Ghana", "Guinea", "Guinea-Bissau", "Ivory Coast",
    "Kenya", "Lesotho", "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania",
    "Mauritius", "Morocco", "Mozambique", "Namibia", "Niger", "Nigeria", "Rwanda",
    "São Tomé and Príncipe", "Senegal", "Seychelles", "Sierra Leone", "Somalia",
    "South Africa", "South Sudan", "Sudan", "Tanzania", "Togo", "Tunisia", "Uganda",
    "Zambia", "Zimbabwe"
];

const investorTypes = [
    "Hands-on (mentorship/guidance)",
    "Silent partner (just funding)",
    "Industry expert",
    "Network/partnerships"
];

const steps = [
    { id: 1, title: "Company Details" },
    { id: 2, title: "Business Info" },
    { id: 3, title: "Security" }
];

export default function SMERegisterForm() {
    const [step, setStep] = useState(1);
    const [form, setForm] = useState({
        businessName: "", founderName: "", email: "", contact: "",
        stage: "", industry: "", funding: "", country: "", investor: "",
        password: "", confirmPassword: "", terms: false
    });
    const [isRegistered, setIsRegistered] = useState(false);
    const [errors, setErrors] = useState({
        contact: "",
        funding: ""
    });

    const isValidEmail = (email) =>
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

    const isValidContact = (contact) =>
        /^[0-9]{7,15}$/.test(contact);

    const isValidFunding = (funding) =>
        /^[0-9]+$/.test(funding);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setForm({ ...form, [name]: type === "checkbox" ? checked : value });
    };

    const next = () => {
        if (step === 1) {
            if (!form.businessName || !form.founderName || !form.email || !form.contact) {
                alert("Please fill in all required fields.");
                return;
            }
            if (!isValidEmail(form.email)) {
                alert("Please enter a valid email address.");
                return;
            }
            if (!isValidContact(form.contact)) {
                setErrors({ ...errors, contact: "Please enter a valid contact number (digits only, 7-15 characters)." });
                return;
            } else {
                setErrors({ ...errors, contact: "" });
            }
        }
        if (step === 2) {
            if (!form.stage || !form.industry || !form.country || !form.investor) {
                alert("Please complete all required selections.");
                return;
            }
            if (!isValidFunding(form.funding)) {
                setErrors({ ...errors, funding: "Please enter a valid funding amount (numbers only)." });
                return;
            } else {
                setErrors({ ...errors, funding: "" });
            }
        }
        setStep(step + 1);
    };

    const back = () => setStep(step - 1);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!form.password || form.password.length < 6) {
            alert("Password must be at least 6 characters long.");
            return;
        }
        if (form.password !== form.confirmPassword) {
            alert("Passwords do not match.");
            return;
        }
        if (!form.terms) {
            alert("Please agree to the terms.");
            return;
        }

        console.log("Registering:", form);
        setIsRegistered(true);
    };

    if (isRegistered) {
        return (
            <div className="form-wrapper">
                <h2>Verify Your Email</h2>
                <p>
                    We’ve sent a verification code to <strong>{form.email}</strong>.
                    Please enter it below to confirm your registration.
                </p>
                <form onSubmit={(e) => {
                    e.preventDefault();
                    alert("Code verified. You can redirect now.");
                }}>
                    <label>Verification Code:</label>
                    <input name="code" placeholder="Enter code..." />
                    <button type="submit" style={{ marginTop: "1rem" }}>Verify</button>
                </form>
                <p style={{ marginTop: "1rem" }}>
                    Didn’t get it?{" "}
                    <button type="button" onClick={() => alert("Resend code logic here")}>
                        Resend Code
                    </button>
                </p>
            </div>
        );
    }

    return (
        <div className="form-wrapper">
            <h2>Register Your Business</h2>

            <div className="step-tracker">
                {steps.map((s, idx) => (
                    <div key={s.id} className={`step ${step === s.id ? "active" : step > s.id ? "completed" : ""}`}>
                        <div className="circle">{s.id}</div>
                        <div className="label">{s.title}</div>
                        {idx < steps.length - 1 && <div className="line" />}
                    </div>
                ))}
            </div>

            <form onSubmit={handleSubmit}>
                {step === 1 && (
                    <div className="form-section">
                        <label>Business Name:</label>
                        <input name="businessName" value={form.businessName} onChange={handleChange} placeholder="Business Name..." />
                        <label>Founder's Name:</label>
                        <input name="founderName" value={form.founderName} onChange={handleChange} placeholder="Founder's Name..." />
                        <label>Email:</label>
                        <input type="email" name="email" value={form.email} onChange={handleChange} placeholder="Email..." />
                        <label>Contact:</label>
                        <input name="contact" value={form.contact} onChange={handleChange} placeholder="Contact..." />
                        {errors.contact && <div className="error">{errors.contact}</div>}
                    </div>
                )}

                {step === 2 && (
                    <div className="form-section">
                        <label>Business Stage:</label>
                        <select name="stage" value={form.stage} onChange={handleChange}>
                            <option value="">Choose...</option>
                            {businessStages.map((s, i) => <option key={i} value={s}>{s}</option>)}
                        </select>
                        <label>Industry:</label>
                        <select name="industry" value={form.industry} onChange={handleChange}>
                            <option value="">Choose...</option>
                            {industries.map((i, idx) => <option key={idx} value={i}>{i}</option>)}
                        </select>
                        <label>Funding Amount:</label>
                        <input name="funding" value={form.funding} onChange={handleChange} placeholder="e.g. R50,000" />
                        {errors.funding && <div className="error">{errors.funding}</div>}
                        <label>Country:</label>
                        <select name="country" value={form.country} onChange={handleChange}>
                            <option value="">Choose...</option>
                            {africanCountries.map((c, i) => <option key={i} value={c}>{c}</option>)}
                        </select>
                        <label>Investor Type:</label>
                        <select name="investor" value={form.investor} onChange={handleChange}>
                            <option value="">Choose...</option>
                            {investorTypes.map((t, i) => <option key={i} value={t}>{t}</option>)}
                        </select>
                    </div>
                )}

                {step === 3 && (
                    <div className="form-section">
                        <label>Password:</label>
                        <input type="password" name="password" value={form.password} onChange={handleChange} />
                        <label>Confirm Password:</label>
                        <input type="password" name="confirmPassword" value={form.confirmPassword} onChange={handleChange} />
                        <label className="checkbox">
                            <input type="checkbox" name="terms" checked={form.terms} onChange={handleChange} />
                            I agree to the terms and conditions
                        </label>
                    </div>
                )}

                <div className="form-buttons">
                    {step > 1 && <button type="button" onClick={back}>Back</button>}
                    {step < 3 ? (
                        <button type="button" onClick={next}>Continue</button>
                    ) : (
                        <button type="submit">Register</button>
                    )}
                </div>
            </form>
        </div>
    );
}
