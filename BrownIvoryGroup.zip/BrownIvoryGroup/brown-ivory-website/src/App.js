import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import HomePage from "./components/HomePage";
import ChooseUserType from "./components/ChooseUserType";
import SMERegisterForm from "./components/SMERegisterForm";
import InvestorRegisterForm from "./components/InvestorRegisterForm";
import LoginSlider from "./components/LoginSlider"; // 👈 New component

export default function App() {
  return (
    <Router>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/choose-user-type" element={<ChooseUserType />} />
          <Route path="/login" element={<LoginSlider />} /> {/* 👈 Unified login screen */}
          <Route path="/register-sme" element={<SMERegisterForm />} />
          <Route path="/register-investor" element={<InvestorRegisterForm />} />
        </Route>
      </Routes>
    </Router>
  );
}
